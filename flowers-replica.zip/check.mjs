import assert from 'node:assert/strict';
import { readFileSync, existsSync } from 'node:fs';
import { Script } from 'node:vm';

const html = readFileSync(new URL('index.html', import.meta.url), 'utf8');
const css = readFileSync(new URL('styles.css', import.meta.url), 'utf8');
const js = readFileSync(new URL('script.js', import.meta.url), 'utf8');
const ids = [...html.matchAll(/\bid="([^"]+)"/g)].map(match => match[1]);
assert.equal(new Set(ids).size, ids.length, 'IDs devem ser únicos.');

for (const [, target] of html.matchAll(/href="#([^"]+)"/g)) {
  assert(ids.includes(target), `Destino interno ausente: ${target}`);
}
for (const [, asset] of (html + css).matchAll(/(?:src="|href="|url\(')(assets\/[^"')]+)/g)) {
  assert(existsSync(new URL(asset, import.meta.url)), `Asset ausente: ${asset}`);
}
assert.equal((html.match(/data-bouquet=/g) || []).length, 3, 'O catálogo deve conter três buquês.');
new Script(js);
console.log('OK: links internos, IDs, assets, três buquês e sintaxe JavaScript.');
