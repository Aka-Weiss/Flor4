const menuButton = document.querySelector('.menu-toggle');
const navigation = document.querySelector('#navigation');
const dialog = document.querySelector('.detail-dialog');

function closeMenu() {
  navigation.classList.remove('is-open');
  menuButton.setAttribute('aria-expanded', 'false');
  menuButton.setAttribute('aria-label', 'Открыть меню');
}

menuButton.addEventListener('click', () => {
  const open = navigation.classList.toggle('is-open');
  menuButton.setAttribute('aria-expanded', String(open));
  menuButton.setAttribute('aria-label', open ? 'Закрыть меню' : 'Открыть меню');
});
navigation.addEventListener('click', (event) => {
  if (event.target.closest('a, button')) closeMenu();
});
document.addEventListener('keydown', (event) => {
  if (event.key === 'Escape' && navigation.classList.contains('is-open')) {
    closeMenu();
    menuButton.focus();
  }
});
document.addEventListener('click', (event) => {
  if (!event.target.closest('.header')) closeMenu();
});
matchMedia('(max-width: 600px)').addEventListener('change', closeMenu);

// A referência é estática. Os detalhes são demonstrativos, sem simular pedidos enviados.
const details = {
  classic: ['Классика', 'Нежные розовые и кремовые пионы в лаконичной светлой упаковке. Букет для самых теплых слов.'],
  minimal: ['Минимализм', 'Легкая композиция, тонкие линии и естественная красота цветов. Ничего лишнего.'],
  premium: ['Премиум', 'Пышные пионы, нежные оттенки и ветви эвкалипта. Выразительная композиция для особенного момента.'],
  about: ['Больше чем цветы', 'Мы создаем цветочные истории для самых важных моментов жизни. Каждый букет — это сочетание красоты, эмоций и заботы.'],
  delivery: ['Доставка', 'Условия, стоимость и зона доставки появятся после подключения магазина.'],
  contacts: ['Контакты', 'Контакты флориста появятся после подключения магазина. Сейчас вы можете познакомиться с нашей коллекцией букетов.'],
};

document.querySelectorAll('[data-info], [data-bouquet]').forEach((button) => {
  button.addEventListener('click', () => {
    const [title, description] = details[button.dataset.info || button.dataset.bouquet];
    document.querySelector('#dialog-title').textContent = title;
    document.querySelector('#dialog-description').textContent = description;
    dialog.showModal();
  });
});
document.querySelector('.dialog-close').addEventListener('click', () => dialog.close());
document.querySelector('.dialog-return').addEventListener('click', () => dialog.close());
dialog.addEventListener('click', (event) => {
  const bounds = dialog.getBoundingClientRect();
  if (event.target === dialog && (event.clientX < bounds.left || event.clientX > bounds.right || event.clientY < bounds.top || event.clientY > bounds.bottom)) {
    dialog.close();
  }
});
